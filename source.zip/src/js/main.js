function goToIntro() {
    window.location.href = 'main.html';
}

function goToStart() {
    window.location.href = 'index.html';
}

function restart() {
    window.location.reload();
}
